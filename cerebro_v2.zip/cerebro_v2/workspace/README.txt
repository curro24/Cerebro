Esta es la carpeta a la que Cerebro V2 tiene acceso.

Pon aquí un proyecto de prueba.

Ejemplo:
workspace/
  mi_proyecto/
    main.py
    README.md
